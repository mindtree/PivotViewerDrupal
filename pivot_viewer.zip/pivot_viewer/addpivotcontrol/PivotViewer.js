var JS_DS_PARAM_NAMES = {
		folder: 'FolderPath',
		account: 'AccountName',
		container: 'ContainerName',
		secret_key : 'Key',
		odata_src: 'src',
		twitter_user: 'user',
		others_source: 'URL'
		};

function onSilverlightError(sender, args) {	
	var appSource = "";
	if (sender != null && sender != 0) {
		appSource = sender.getHost().Source;
	}

	var errorType = args.ErrorType;
	var iErrorCode = args.ErrorCode;

	if (errorType == "ImageError" || errorType == "MediaError") {
		return;
	}
	var errMsg = "Unhandled Error in Silverlight Application " + appSource
			+ "\n";
	errMsg += "Code: " + iErrorCode + "    \n";
	errMsg += "Category: " + errorType + "       \n";
	errMsg += "Message: " + args.ErrorMessage + "     \n";

	if (errorType == "ParserError") {
		errMsg += "File: " + args.xamlFile + "     \n";
		errMsg += "Line: " + args.lineNumber + "     \n";
		errMsg += "Position: " + args.charPosition + "     \n";
	} else if (errorType == "RuntimeError") {
		if (args.lineNumber != 0) {
			errMsg += "Line: " + args.lineNumber + "     \n";
			errMsg += "Position: " + args.charPosition + "     \n";
		}
		errMsg += "MethodName: " + args.methodName + "     \n";
	}

	throw new Error(errMsg);
}

function loadCollection(id, collectionUrl, accountName, containerName, secretKey, folderPath) {
	if (collectionUrl == null || collectionUrl == "")
		return;
	
	if(document.getElementById('pivot_viewer_'+id)){
		var pivot = document.getElementById('pivot_viewer_'+id);	
		
	//alert(collectionUrl+ accountName+ containerName+ secretKey+ folderPath);
				
	pivot.Content.pivotViewer.LoadCollection(collectionUrl, accountName, containerName, secretKey, folderPath);
	}	
}


function loadPivotControl()
{	
	var c_len = pivotControlList.length;	
	for(var i=0; i<c_len; i++)
	{
		var pC = pivotControlList[i];		
		var collectionUrl = '';
		var accountName = '';
		var containerName = '';
		var secretKey = '';
		var folderPath = '';
		switch(pC.type)
		{
			case 'ServerFolder':
				folderPath = getCollectionParam(JS_DS_PARAM_NAMES.folder, pC.collection_params);
				collectionUrl = 'DataSource=' + pC.type;
				break;
			case 'WindowsAzureBlob':
				collectionUrl = 'DataSource=' + 'Blob';	//pC.type;
				accountName = getCollectionParam(JS_DS_PARAM_NAMES.account, pC.collection_params);
				containerName = getCollectionParam(JS_DS_PARAM_NAMES.container, pC.collection_params);
				secretKey = getCollectionParam(JS_DS_PARAM_NAMES.secret_key, pC.collection_params);
				break;	
			case 'OData':
			case 'Twitter':							
				collectionUrl = 'DataSource=' + pC.type + '&' + pC.collection_params;				
				break;
			case 'Others':				
				collectionUrl = getCollectionParam(JS_DS_PARAM_NAMES.others_source, pC.collection_params);					
				break;
		}		
		
		loadCollection(pivotControl.id, collectionUrl, accountName, containerName, secretKey, folderPath);
	}		
}

function getCollectionParam(attrib, param)
{
	var pattern = '('+attrib + '=' + ')(.*)';		
	var re = new RegExp(pattern, "ig");

	var params = param.split(",");
	var p_len = params.length;
	for(var i = 0; i<p_len; i++)
	{				
		var match = re.exec(params[i]);
		if(match){
			return match[2];
		}			
	}	
	return '';
}

// $Id: bing_button.js $

/**
 * @file
 * Javascript for Field Button.
 */

var cursorPositionPV = {}; 
(function ($) {
	$(document).ready(function() {
		
		$('#edit-body-und-0-value').bind('keypress mousedown', function(){			
			storeCaretPV('edit-body-und-0-value');
		});
	
		document.getElementById('pvbutton').onclick = function(){
			var qq = document.getElementById('pvdropdown').selectedIndex;
			var ddSel = document.getElementById('pvdropdown').options[qq].text;
			var ddVal = document.getElementById('pvdropdown').options[qq].value;			
			if(ddVal != 0)
			{
				var macro = '{pivotviewer id="'+ddVal+'" name="'+ddSel+'"}';	
				
				if(document.getElementsByTagName("textarea").length>0)
				{
					if ($("#edit-body-und-0-value").length > 0)
					{			
						var editor_el = document.getElementById('edit-body-und-0-value');
						
						var content = editor_el.value;	
						var pivotMacro = content.match(/{pivotviewer.*?\}/i);
						if (pivotMacro) {
							content = content.replace(/{pivotviewer.*?\}/i, macro);
							editor_el.value = content;
						} else {
							insertAtCaretPV(editor_el, macro);				
						}	
						
						return false;
					}
					else
					{
						alert('Please copy and paste the macro at desired location:'+macro);
						return false;
					}
				}
			}
			else
			{
				alert('Please select an option');
				return false;
			}
		}
		
	});		
})(jQuery);

function storeCaretPV(areaId) { 
	var txtarea = document.getElementById(areaId);	 
	var br = ((txtarea.selectionStart || txtarea.selectionStart == '0') ? "ff" : (document.selection ? "ie" : false ) ); 
	if (br == "ie") {		 
		cursorPositionPV.range = document.selection.createRange();			
	} else if (br == "ff"){
		cursorPositionPV.strPos = txtarea.selectionStart;	
		
	}	
} 


function insertAtCaretPV(txtarea,text) {	
	if(cursorPositionPV.range || cursorPositionPV.strPos){
	var br = ((txtarea.selectionStart || txtarea.selectionStart == '0') ? "ff" : (document.selection ? "ie" : false ) ); 
		if (br == "ie") {
			if(cursorPositionPV.range){				
				cursorPositionPV.range.text = text;			
			} 		
		} else if (br == "ff"){
			if(cursorPositionPV.strPos){
				var strPos = cursorPositionPV.strPos;	
				var front = (txtarea.value).substring(0,strPos); 
				var back = (txtarea.value).substring(strPos,txtarea.value.length); 
				txtarea.value=front+text+back; strPos = strPos + text.length;
			}	
		} 
	} else {
		txtarea.value += text;
	}	
	 
} 


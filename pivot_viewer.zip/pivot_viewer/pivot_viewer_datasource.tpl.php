<fieldset class="adminform" style="margin-bottom: 15px;">
		<legend style="font-weight: bold;"><?php if(!empty($ds_id)) echo 'Edit ';?>Data Sources </legend>
			<div class="outerDiv2">
				<div class="seperationDiv">
					<div style=" float: left; width: 68px;">			
						<label class="hasTip required" style="white-space: nowrap; width: 36px; clear: none; margin-right: 10px;" for="jform_ds_name" id="ds_name-lbl">Name:<span title="This field is required." class="form-required">*</span></label>
					</div>
					<div style="float: left; width: 375px;">
						<input type="text" size="20" id="ds_name" class="form-text"/>
					</div>
				</div>
				<div class="seperationDiv">
					<div style="margin-top: 10px; width: 61px; float: left;">
						<label class="hasTip required" style="white-space: nowrap; width: 50px; clear: none; margin-right: 16px;" for="jform_ds_type" id="ds_datasource-lbl">Type:<span title="This field is required." class="form-required">*</span></label>
					</div>
					<div style="margin-top: 10px; width: 61px; float: left;">
						<select class="block-region-select block-region--1 form-select block-region-select-processed" id="ds_type" name="ds_type" onchange="showHideDSFields(this.value);">
							<?php			
								$options = array(	'' => '&lt;Datasource Type&gt;',
									 	'ServerFolder' => 'Media Folder',
										'WindowsAzureBlob' => 'Windows Azure Blob',
										'OData' => 'OData',
										'Twitter' => 'Twitter',
										'Others' => 'Pivot Collection',	
										);		 
										
								$datasource_options = '';
								
									foreach($options as $key => $datasource_type)
									{
										$datasource_options .= "<option value='{$key}'>{$datasource_type}</option>";
									}	
								
								echo $datasource_options;
							?>
						</select>
					</div>
					<div>
						<span id="DS_ServerFolder_Fields" style="display:none; float: left; width: 770px; margin-top: 10px;">
							<label class="hasTip required" style="white-space:nowrap;width:80px;margin-left:5px;clear:none" for="jform_ds_folder" id="ds_folder-lbl">Folder path<span title="This field is required." class="form-required">*</span></label>
							<input type="text" size="40" id="ds_folder" class="form-text"/>
						</span>		
						<span id="DS_WindowsAzureBlob_Fields" style="display:none; float: left; width: 770px; margin-top: 10px;">					
							<input class="form-text" style="margin-left: 10px; float: left;" type="checkbox" id="ds_is_public" onClick="showHideSecretKeyField(this.checked);" checked="checked"/>
							<label style="white-space: nowrap; width: 40px; margin-left: 5px; clear: none; float: left;" for="jform_ds_is_public" id="ds_is_public-lbl">Public</label>
							<label class="form-text" style="white-space: nowrap; width: 100px; clear: none; margin-left: 30px; float: left;" for="jform_ds_account_name" id="ds_account_name-lbl">Account Name<span title="This field is required." class="form-required">*</span></label>
							<input class="form-text" type="text" size="9" id="ds_account_name" style="width: 82px; float: left; margin-left: 30px;"/>
							<label style="white-space: nowrap; width: 110px; margin-left: 5px; clear: none; float: left;" for="jform_ds_container_name" id="ds_container_name-lbl">Container Name<span title="This field is required." class="form-required">*</span></label>
							<input type="text" class="form-text" size="9" id="ds_container_name" style="width: 82px; float: left; margin-left: 34px;"/>					
							<span id="DS_Blob_SecretKey_Field" style="display:none; width: 200px; float: left;">	
								<label class="hasTip required" style="white-space: nowrap; width: 80px; margin-left: 5px; clear: none; float: left;" for="jform_ds_secret_key" id="ds_secret_key-lbl">Secret Key<span title="This field is required." class="form-required">*</span></label>
								<input type="text" class="form-text" size="9" id="ds_secret_key" style="width: 82px; margin-left: 18px;"/>
							</span>					
						</span>
						<span id="DS_OData_Fields" style="display:none; float: left; width: 770px; margin-top: 10px;">
							<label class="hasTip required" style="white-space:nowrap;width:40px;margin-left:5px;clear:none" for="jform_ds_url" id="ds_url-lbl">URL<span title="This field is required." class="form-required">*</span></label>
							<input type="text" size="60" id="ds_url" class="form-text"/>
						</span>
						<span id="DS_Twitter_Fields" style="display:none; float: left; width: 770px; margin-top: 10px;">
							<label class="hasTip required" style="white-space:nowrap;width: 125px;margin-left:5px;clear:none; float: left;" for="jform_ds_folder" id="ds_folder-lbl">
									<input id="ds_user" type="radio" name="group1[]" value="User" onchange="showHideTwitter(this.value);" onfocus="showHideTwitter(this.value);" checked>User Name<br>
									<input id="ds_topic" type="radio" name="group1[]" value="Topic" onchange="showHideTwitter(this.value);" onfocus="showHideTwitter(this.value);">Topic Name<br>
								
							</label>
							<div class="twitterBoxUser">
								<span id="DS_Twitter_User" style="display:inline">
									
									<input type="text" size="20" id="ds_user_name" class="form-text" style="margin-bottom: 2px;"/>
								</span>
							</div>
							<div class="twitterBoxTopic">
								<span id="DS_Twitter_Topic" style="display:inline;">
									
									<input type="text" size="20" id="ds_topic_name" class="form-text" style=""/>
								</span>
							</div>	
						</span>	
						<span id="DS_Others_Fields" style="display:none; float: left; width: 770px; margin-top: 10px;">
							<label class="hasTip required" style="white-space:nowrap;width:60px;margin-left:5px;clear:none" for="jform_ds_source" id="ds_others-lbl">Source<span title="This field is required." class="form-required">*</span></label>
							<input type="text" size="60" id="ds_source" class="form-text"/>
						</span>
					</div>	
				</div>		
				<div class="seperationDiv_forbuttons" style="padding-top:12px">
						<?php 
							if(empty($ds_id))
							{
							?>
							<input type="button" value="Add"  id="ds_add" class="form-submit"/>	
							<?php  
							} else{
							?>
							<input type="button" value="Update"  id="ds_add" class="form-submit"/>
							<input type="button" value="Cancel" id="ds_cancel" class="form-submit" />
						<?php 
							}
						?>						
				</div>					
			</div>
	</fieldset>
	<span style="font-size: 10px;">All the fields marked with <span class="form-required">*</span> are mandatory</span>
<?php
// $Id: 

$site_base_path = base_path();
?>


<script type="text/javascript">
	var site_base_path = '<?php echo $site_base_path; ?>';
	var tempDSType = null;
	var ajaxRequest = null;  // The variable that makes Ajax possible!
	var url = '?q=admin/pvc/configure';
	var loadedData;

	var JS_DS_SERVERFOLDER_PATH = 'FolderPath';
	var JS_DS_BLOB_ACCOUNT_NAME = 'AccountName';
	var JS_DS_BLOB_CONTAINER_NAME = 'ContainerName';
	var JS_DS_BLOB_SECRET_KEY = 'Key';
	var JS_DS_ODATA_SRC = 'src';
	var JS_DS_TWITTER_USER = 'user';
	var JS_DS_TWITTER_TOPIC = 'topic';
	var JS_DS_OTHERS_SOURCE = 'URL';


	//Browser Support Code
	function initializeAjax()
	{
		try{
			// Opera 8.0+, Firefox, Safari
			ajaxRequest = new XMLHttpRequest();
		} catch (e){
			// Internet Explorer Browsers
			try{
				ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
			} catch (e) {
				try{
					ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
				} catch (e){
					// Something went wrong
					alert("Your browser does not support Ajax!");
					return false;
				}
			}
		}
	}
	
	function showHideDSFields(selectedDSType)
	{		
		if(selectedDSType != ''){			
			document.getElementById('DS_'+selectedDSType+'_Fields').style.display = 'inline';
			
		} else {
			/*document.getElementById('DS_Button').style.display = 'none';*/
		}	

		if(selectedDSType == 'Twitter'){
			if(document.getElementById('ds_user').checked == true)
			{
				document.getElementById('DS_Twitter_User').style.display = 'inline';
				document.getElementById('ds_user_name').disabled = false;
				document.getElementById('ds_topic_name').disabled = true;
			}
			else
			{
				document.getElementById('DS_Twitter_Topic').style.display = 'inline';
				document.getElementById('ds_user_name').disabled = true;
				document.getElementById('ds_topic_name').disabled = false;
			}
		}		

		if(selectedDSType == 'ServerFolder'){
			if(document.getElementById('ds_id').value == null || document.getElementById('ds_id').value == '') 
				document.getElementById('ds_folder').value='\\sites\\default\\files';
		}
		
		if(tempDSType && tempDSType != selectedDSType){
			document.getElementById('DS_'+tempDSType+'_Fields').style.display = 'none';			
		}
		tempDSType = selectedDSType;
	}

	function showHideSecretKeyField(isPublic)
	{
		if(!isPublic){
			document.getElementById('DS_Blob_SecretKey_Field').style.display = 'inline';
		} else {
			document.getElementById('DS_Blob_SecretKey_Field').style.display = 'none';
		}
	}

	function setToolTip()
	{
		jQuery("#content_type-lbl").attr('title', ASSOCIATE_TO_CONTENT_TYPE);
		jQuery("#ds_name-lbl").attr('title', NAME_OF_DATASOURCE);
		jQuery("#ds_datasource-lbl").attr('title', DATASOURCE_TYPE);
		
		jQuery("#ds_is_public-lbl").attr('title', PRIVACY);
		jQuery("#ds_account_name-lbl").attr('title', ACCOUNT_NAME);
		jQuery("#ds_container_name-lbl").attr('title', CONTAINER_NAME);
		jQuery("#ds_secret_key-lbl").attr('title', SECRET_KEY);

		jQuery("#ds_folder-lbl").attr('title', FOLDER);
		jQuery("#ds_url-lbl").attr('title', ODATA_URL);
		jQuery("#ds_user_name-lbl").attr('title', TWITTER_USERNAME);
		jQuery("#ds_others-lbl").attr('title', OTHERS_LOCATION);
	}

	(function ($) {
		$(document).ready(function() {
			
			initializeAjax();
			<?php 
				if(empty($ds_id))
				{
			?>
			loadConfigList();			
			loadDSList();	
			setToolTip();
			<?php 
				} else {				
					echo "loadDataSourceDetails('{$ds_id}');";
					
				}
			?>
			
			$("#ds_add").click(function () { 
				
				var ds_id = document.getElementById('ds_id').value;
				ds_id = ds_id ? ds_id : null;
				
				var ds_name = document.getElementById('ds_name').value;
				var ds_type = document.getElementById('ds_type').value;
				
				var collection_params = '';
				var reEmpty = /[^\s]/;
				var errors = [];
				var emptyError = false;
				switch(ds_type)
				{
					case 'ServerFolder':
						
						var ds_folder = document.getElementById('ds_folder').value;
						
						if(!reEmpty.test(ds_folder)){
							emptyError = true;				
						} else {
							collection_params=JS_DS_SERVERFOLDER_PATH+"="+ds_folder;
						}
						
						break; 
					case 'WindowsAzureBlob':
						if(document.getElementById('ds_is_public').checked)
							var ds_is_public = true;
						else
							var ds_is_public = false;
	
						var ds_account_name = document.getElementById('ds_account_name').value;
						var ds_container_name = document.getElementById('ds_container_name').value;
						var ds_secret_key = document.getElementById('ds_secret_key').value;
						if(!reEmpty.test(ds_account_name) || !reEmpty.test(ds_container_name) || (!ds_is_public && !reEmpty.test(ds_secret_key))){
							emptyError = true;				
						} else {
							collection_params=JS_DS_BLOB_ACCOUNT_NAME+"="+ds_account_name+","+JS_DS_BLOB_CONTAINER_NAME+"="+ds_container_name;
							if(!ds_is_public){
								collection_params+=","+JS_DS_BLOB_SECRET_KEY+"="+ds_secret_key;
							}
						}		

						break;
					case 'OData':
						var ds_url =  document.getElementById('ds_url').value;
						if(!reEmpty.test(ds_url)){
							emptyError = true;				
						} else if(!isValidSource(ds_url)){
							errors.push("You must supply a valid Source");
							document.getElementById('ds_url').focus();
						} else {
							collection_params=JS_DS_ODATA_SRC+"="+ds_url;
						}

						break;
					case 'Twitter':
						var ds_user_name = document.getElementById('ds_user_name').value;		
						var ds_topic_name = document.getElementById('ds_topic_name').value;
						
						
						var ds_user = document.getElementById('ds_user').checked;

						if(document.getElementById('ds_user').checked)
						{
							if(!reEmpty.test(ds_user_name)){
								emptyError = true;				
							} else {
								collection_params=JS_DS_TWITTER_USER+"="+ds_user_name;
							}
						}
						else if(document.getElementById('ds_topic').checked)
						{
							if(!reEmpty.test(ds_topic_name)){
								emptyError = true;				
							} else {
								collection_params=JS_DS_TWITTER_TOPIC+"="+ds_topic_name;
							}
						}
				
						break;
					case 'Others':
						var ds_source = document.getElementById('ds_source').value;
						if(!reEmpty.test(ds_source)){
							emptyError = true;				
						} else if(!isValidSource(ds_source)){
							errors.push("You must supply a valid Source");
							document.getElementById('ds_source').focus();
						} else {
							collection_params=JS_DS_OTHERS_SOURCE+"="+ds_source;
						}

						break;			
				}

				if(!reEmpty.test(ds_name) || !reEmpty.test(ds_type) || emptyError){
					errors.push("Please provide details for all mandatory fields");				
				}

				if(errors.length > 0){
					alert(errors.join("\n"));
					return false;
				}
				
				$('#ajax-container').html('<span>Please wait...</span>');

				$.post(url, { ds_id : ds_id, ds_name : ds_name, ds_type : ds_type, collection_params : collection_params }, loadStage);
					
			});			

			$("#ds_cancel").click(function () {								
				window.location.href = "?q=admin/pvc/configure&render=overlay";
			});		
					
		});
	})(jQuery);

	function loadStage(data)
	{
		alert(data);		
		if(jQuery('#ds_id').val() == ''){ 
			loadDSList();
			functionReset();
		} else {			
			jQuery("#ds_cancel").trigger('click');	
		}
	}

	function isValidSource(source)
	{
		var v = new RegExp(); 
		v.compile(/^(http|https)/);
		return v.test(source);
	}
	
	function functionReset()
	{
		document.getElementById('ds_id').value = null;
		document.getElementById('ds_add').value = 'Add';

		document.getElementById('ds_name').value = '';
		document.getElementById('ds_type').value = '';

		document.getElementById('ds_folder').value = '';
		document.getElementById('ds_account_name').value = '';
		document.getElementById('ds_container_name').value = '';
		document.getElementById('ds_secret_key').value = '';
		document.getElementById('ds_url').value = '';
		document.getElementById('ds_user_name').value = '';
		document.getElementById('ds_source').value = '';

		document.getElementById('ds_user').checked = true;
		document.getElementById('ds_topic_name').value = '';

		showHideTwitter('User');
		showHideDSFields('');
		
	}

	function loadConfigList()
	{
		var configGet = 'configGet';
		jQuery.get(url, {configData : configGet}, ConfigCallback);
	}

	function ConfigCallback(data)
	{
		var pins = data.split(",");

		var list = document.getElementById('content_type');
		for(var i=0; i<list.options.length; ++i)
		{
			for(var j=0;j<pins.length;j++)
			{
				if(list.options[i].value == pins[j])
					list.options[i].selected = true;
			}
		}
	}
	
	function loadDSList()
	{
		var dataGet = 'dataGet';
		
		if (ajaxRequest != null)
	    {	       
		    ajaxRequest.onreadystatechange = function()
		    {
		      if(ajaxRequest.readyState == 4)
		      {
		    	  jQuery('#ajax-container').html( ajaxRequest.responseText);
		      }
		    }		    
		    ajaxRequest.open("GET", "?q=admin/pvc/configure&pivotData=" + dataGet, true); 
		    ajaxRequest.send(null);	    
	   	}
	   	
	}

	function loadDataSourceDetails(ds_id)
	{
		jQuery.get(url, {ds_id : ds_id }, GetCallback);
		document.getElementById('ds_id').value = ds_id;
		document.getElementById('ds_add').value = 'Update';
		
		highlightRow(ds_id, 'green');
	}

	function GetCallback(jsonData)
	{
		if(navigator.appName == "Microsoft Internet Explorer")
		{
			var d = eval('(' + jsonData + ')');
			
			document.getElementById('ds_name').value = d[0].name;
			document.getElementById('ds_type').value = d[0].type;
			loadCollectionParamsToFields(d[0].type, d[0].collection_params);
			showHideDSFields(d[0].type);
		}
		else
		{
			var myObject = JSON.parse(jsonData);

		    jQuery.each(myObject, function(i, item) {
		       if(item.id)
			   {
		    	   	document.getElementById('ds_name').value = item.name;
					document.getElementById('ds_type').value = item.type;
					loadCollectionParamsToFields(item.type, item.collection_params);
					showHideDSFields(item.type)
			   }				
		    });
		}
	}

	function loadCollectionParamsToFields(ds_type, collection_params){
		switch(ds_type)
		{
			case 'ServerFolder':				
				var ds_folder = getParam(JS_DS_SERVERFOLDER_PATH, collection_params);
				
				document.getElementById('ds_folder').value = ds_folder;

				break; 
				
			case 'WindowsAzureBlob':	
				var ds_account_name = getParam(JS_DS_BLOB_ACCOUNT_NAME, collection_params);
				document.getElementById('ds_account_name').value = ds_account_name;
							
				var ds_container_name = getParam(JS_DS_BLOB_CONTAINER_NAME, collection_params);	
				document.getElementById('ds_container_name').value = ds_container_name;

				var ds_secret_key = getParam(JS_DS_BLOB_SECRET_KEY, collection_params);		

				if(ds_secret_key == 'null' || ds_secret_key == null || ds_secret_key == '')
				{
					document.getElementById('ds_is_public').checked = true;
					document.getElementById('ds_secret_key').value = '';
					showHideSecretKeyField(true);
				}
				else
				{
					document.getElementById('ds_is_public').checked = false;
					document.getElementById('ds_secret_key').value = ds_secret_key;
					showHideSecretKeyField(false);
				}
				
				break;
				
			case 'OData':				
				var ds_url = getParam(JS_DS_ODATA_SRC, collection_params);			
				document.getElementById('ds_url').value	= ds_url;

				break;
				
			case 'Twitter':				
				var ds_user_name = getParam(JS_DS_TWITTER_USER, collection_params);
				var ds_topic_name = getParam(JS_DS_TWITTER_TOPIC, collection_params);

				if(ds_user_name == '' && ds_topic_name != '')
				{	
					document.getElementById('ds_topic').checked = true;

					showHideTwitter('Topic');
					document.getElementById('ds_topic_name').value = ds_topic_name;
	
				}
				else if(ds_user_name != '' && ds_topic_name == '')
				{
					document.getElementById('ds_user').checked = true;

					showHideTwitter('User');
					document.getElementById('ds_user_name').value = ds_user_name;
					
				}
		
				break;
				
			case 'Others':				
				var ds_source = getParam(JS_DS_OTHERS_SOURCE, collection_params);
				document.getElementById('ds_source').value = ds_source;

				break;				
		}
	}
		
	function getParam(attrib, param)
	{
		var pattern = '('+attrib + '=' + ')(.*)';		
		var re = new RegExp(pattern, "ig");

		var params = param.split(",");
		var p_len = params.length;
		for(var i = 0; i<p_len; i++)
		{				
			var match = re.exec(params[i]);
			if(match){
				return match[2];
			}			
		}	
		return '';
	}

	function deleteDataSourceDetails(id, name)
	{
		var flag = confirm("Are you sure you want to delete Data Source?");
		if (flag == false)
			return;
		else
			jQuery.post(url, { id : id}, deleteDSList);	

		functionReset();
		loadDSList();
		return;
	}

	function deleteDSList()
	{
		loadDSList();
		alert('Data Source deleted');
	}

	function checkValues()
	{
		var count = 0;
		for (var i=0; i<document.getElementById('content_type').options.length; i++)
        { 
			if (document.getElementById('content_type').options[i].selected == true)
                	count ++;
        }
        if(count == 0)
        {
        	alert("Please make a selection");
            return false;
		}
	}
	
	function highlightRow(rowId, color)
	{		
			jQuery(('table tr')).removeClass('edited');
			jQuery(('#ds_row_'+rowId)).addClass('edited');
	}


	function showHideTwitter(value)
	{
		/*if(value == 'Topic')
		{
			document.getElementById('DS_Twitter_Topic').style.display = 'inline';
			document.getElementById('DS_Twitter_User').style.display = 'none';
		}
		else if(value == 'User')
		{
			document.getElementById('DS_Twitter_Topic').style.display = 'none';
			document.getElementById('DS_Twitter_User').style.display = 'inline';
		}*/

		if(value == 'Topic')
		{
			document.getElementById('ds_user_name').disabled = true;
			document.getElementById('ds_topic_name').disabled = false;
			document.getElementById('ds_user_name').value = '';
		}
		else if(value == 'User')
		{
			document.getElementById('ds_user_name').disabled = false;
			document.getElementById('ds_topic_name').disabled = true;
			document.getElementById('ds_topic_name').value = '';
		}
	}
	
</script>
<?php 

function locateLibPath()
{

	//$libPath = 'sites/all/modules/pivot_viewer/addpivotcontrol';
	$libPath = drupal_get_path('module', 'pivot_viewer').'/addpivotcontrol';
	if (isset($_SERVER['HTTPS']) && !empty($_SERVER['HTTPS']) && (strtolower($_SERVER['HTTPS']) != 'off')) {
		$https = 's://';
	} else {
		$https = '://';
	}

	$scriptName = $_SERVER['SCRIPT_NAME'];
	$scriptBaseName = basename($_SERVER['SCRIPT_NAME']);
	$scriptPos = strpos($scriptName, $scriptBaseName);
	$scriptPath = substr($scriptName, 0, $scriptPos);
	$scriptFullPath = 'http' . $https . $_SERVER['HTTP_HOST'].$scriptPath;
	
	return ($scriptFullPath.$libPath);		
	
}
?>

<div class="fieldsetWidth" style="width:99%;">
	<?php 
		if(empty($ds_id)){
	?>
	<fieldset class="adminform">
		<legend style="font-weight: bold;">PivotViewer Administration</legend>
			<div class="outerDiv1">
				<form action="<?php echo $_SERVER['PHP_SELF'].'?q=admin/pvc/configure'; ?>" method="post" name="adminForm" id="item-form" onSubmit="return checkValues();">
						<div class="configDet">
							<input type="hidden" size="80" id="collection_builder" name="collection_builder" value="<?php echo locateLibPath();?>"/>
							<label style="white-space:nowrap;width:200px" for="content_type" id="content_type-lbl">Associate it to which content type:<span title="This field is required." class="form-required">*</span></label>
						</div>	
						<div class="configDropdown">
							<select class="block-region-select block-region--1 form-select block-region-select-processed" MULTIPLE id="content_type" name="content_type[]" size="3" style="width: 100px;">					
								<?php 
								$nodetype = node_type_get_types();
								foreach($nodetype as $key => $val)
									foreach($val as $k =>$v)
									{
										if($k == 'name')
										{
								?>						
										<option value="<?php echo $v;?>"><?php echo $v;?></option> 
								<?php 	
											
										}
									} 
								?>
							</select>
						</div>	
				
					 
					<div style="margin-left: 307px; margin-top: 15px; margin-bottom: 0px;">
						<input type="submit" class="form-submit" value="Save Configuration" id="save_config" name="save_config"/>
					</div>
				</form>	
			</div>
	</fieldset>	
	<?php		
		}
		echo theme('pivot_viewer_datasource', array('ds_id' => $ds_id ));
	?>	
</div>
<?php 
	if(empty($ds_id)){
?>
<div class="clr"> </div>
<div class="width-60">
	<div id="ajax-container"></div><div id="acontainer"></div>
	<div id="ds-list"></div>	
	<input type="hidden" name="task" value="" />
</div>
<?php 
	}
?>	
<input id="ds_id" name="ds_id" type="hidden" value="<?php echo $ds_id;?>" />
<div class="clr"></div>
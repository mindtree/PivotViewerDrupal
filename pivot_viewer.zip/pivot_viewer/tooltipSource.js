
var ASSOCIATE_TO_CONTENT_TYPE = 'List of content types to which pivot viewer has to be associated with';
var NAME_OF_DATASOURCE = 'Name of the datasource';
var DATASOURCE_TYPE = 'Type of the datasource';

var PRIVACY = 'Privacy type for the Blob datasource';
var ACCOUNT_NAME = 'Account name for the Blob datasource';
var CONTAINER_NAME = 'Container name for the Blob datasource';
var SECRET_KEY= 'Secret Key for the private Blob datasource';

var FOLDER = 'Location for the ServerFolder datasource';
var ODATA_URL = 'URL address of the OData datasource';
var TWITTER_USERNAME = 'User name for the Twitter datasource';
var OTHERS_LOCATION = 'Location of the collection XML';